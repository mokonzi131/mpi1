// Implement your solutions in this file
#include "hamming.h"

unsigned int hamming(uint64_t x, uint64_t y)
{
    // TODO: calculate the hamming distance and return it
    return 0;
}
